import 'package:flutter/material.dart';
import 'login_screen.dart';
import '../models/user_manager.dart';

class ProfilePage extends StatefulWidget {
  final String userName;
  const ProfilePage({Key? key, required this.userName}) : super(key: key);

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  User? currentUser;
  late TextEditingController _nameController;
  late TextEditingController _emailController;
  late TextEditingController _phoneController;
  late TextEditingController _allergensController;
  late TextEditingController _conditionsController;

  @override
  void initState() {
    super.initState();
    currentUser = UserManager.getUserByName(widget.userName);

    _nameController =
        TextEditingController(text: currentUser?.name ?? widget.userName);
    _emailController = TextEditingController(text: currentUser?.email ?? "");
    _phoneController = TextEditingController(text: currentUser?.phone ?? "");
    _allergensController =
        TextEditingController(text: currentUser?.allergens ?? "");
    _conditionsController =
        TextEditingController(text: currentUser?.conditions ?? "");
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _allergensController.dispose();
    _conditionsController.dispose();
    super.dispose();
  }

  void _saveProfile() {
    if (currentUser != null) {
      setState(() {
        currentUser!.name = _nameController.text;
        currentUser!.phone = _phoneController.text;
        currentUser!.allergens = _allergensController.text;
        currentUser!.conditions = _conditionsController.text;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Perfil actualizado correctamente"),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Text("Cerrar sesión"),
          content: Text("¿Estás seguro de que quieres salir?"),
          actions: [
            TextButton(
              child: Text("Cancelar", style: TextStyle(color: Colors.grey)),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: Text("Salir",
                  style: TextStyle(color: Colors.orange.shade700)),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (context) => LoginScreen()),
                  (Route<dynamic> route) => false,
                );
              },
            ),
          ],
        );
      },
    );
  }

  void _changePhoto() {
    setState(() {
      if (currentUser != null) {
        currentUser!.photoPath = "https://i.imgur.com/tY8K4qC.jpeg";
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Foto de perfil actualizada")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 20),
              GestureDetector(
                onTap: _changePhoto,
                child: Stack(
                  children: [
                    CircleAvatar(
                      radius: 60,
                      backgroundImage: NetworkImage(currentUser?.photoPath ??
                          "https://i.imgur.com/lB5bLMY.jpg"),
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: CircleAvatar(
                        backgroundColor: Colors.orange.shade700,
                        radius: 20,
                        child: Icon(Icons.camera_alt,
                            color: Colors.white, size: 20),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 15),
              Text(
                currentUser?.name ?? widget.userName,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              Text(
                "Cliente",
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              SizedBox(height: 30),
              _buildTextField(
                label: "Nombre",
                icon: Icons.person_outline,
                controller: _nameController,
              ),
              SizedBox(height: 15),
              _buildTextField(
                label: "Correo electrónico",
                icon: Icons.email_outlined,
                controller: _emailController,
                inputType: TextInputType.emailAddress,
                isReadOnly: true,
              ),
              SizedBox(height: 15),
              _buildTextField(
                label: "Teléfono",
                icon: Icons.phone_outlined,
                controller: _phoneController,
                hint: "+34 000 000 000",
                inputType: TextInputType.phone,
              ),
              SizedBox(height: 15),
              _buildTextField(
                label: "Alérgenos",
                icon: Icons.warning_amber_rounded,
                controller: _allergensController,
                hint: "Ej: Látex, Tinte negro...",
              ),
              SizedBox(height: 15),
              _buildTextField(
                label: "Afecciones del cuero cabelludo",
                icon: Icons.medical_services_outlined,
                controller: _conditionsController,
                hint: "Ej: Caspa, Dermatitis, Sensibilidad...",
                maxLines: 3,
              ),
              SizedBox(height: 30),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  foregroundColor: Colors.white,
                  minimumSize: Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: _saveProfile,
                child: Text("Guardar Cambios"),
              ),
              SizedBox(height: 15),
              TextButton.icon(
                onPressed: () => _showLogoutDialog(context),
                icon: Icon(Icons.logout, color: Colors.red),
                label: Text(
                  "Cerrar sesión",
                  style: TextStyle(color: Colors.red, fontSize: 16),
                ),
              ),
              SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required String label,
    required IconData icon,
    required TextEditingController controller,
    String? hint,
    TextInputType inputType = TextInputType.text,
    int maxLines = 1,
    bool isReadOnly = false,
  }) {
    return TextField(
      controller: controller,
      keyboardType: inputType,
      maxLines: maxLines,
      readOnly: isReadOnly,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon, color: Colors.orange.shade700),
        filled: true,
        fillColor: isReadOnly ? Colors.grey[200] : Colors.grey[100],
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        contentPadding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
      ),
    );
  }
}
