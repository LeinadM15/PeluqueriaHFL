import 'package:flutter/material.dart';
import 'home_tab_page.dart';
import 'login_screen.dart';
import 'service_detail_page.dart';
import '../models/user_manager.dart';

class FavoritesPage extends StatefulWidget {
  final String userName;
  const FavoritesPage({Key? key, required this.userName}) : super(key: key);

  @override
  _FavoritesPageState createState() => _FavoritesPageState();
}

class _FavoritesPageState extends State<FavoritesPage> {
  List<ServiceItem> _favoriteServices = [];
  User? currentUser;

  void _loadFavorites() {
    _favoriteServices = allServices.where((service) {
      return UserManager.isServiceLiked(widget.userName, service.title);
    }).toList();
  }

  @override
  void initState() {
    super.initState();
    currentUser = UserManager.getUserByName(widget.userName);
  }

  void _showProfileDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
          ),
          contentPadding: EdgeInsets.all(20),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircleAvatar(
                radius: 30,
                backgroundImage: NetworkImage(currentUser?.photoPath ??
                    "https://i.imgur.com/lB5bLMY.jpg"),
              ),
              SizedBox(height: 15),
              Text(
                "¡Hola, ${widget.userName}!",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),
              Divider(),
              ListTile(
                leading: Icon(Icons.logout),
                title: Text("Cerrar sesión"),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (context) => LoginScreen()),
                    (Route<dynamic> route) => false,
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    _loadFavorites();

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(20.0),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Mis Favoritos ❤️",
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                InkWell(
                  onTap: () => _showProfileDialog(context),
                  borderRadius: BorderRadius.circular(25),
                  child: CircleAvatar(
                    radius: 25,
                    backgroundImage: NetworkImage(currentUser?.photoPath ??
                        "https://i.imgur.com/lB5bLMY.jpg"),
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            _favoriteServices.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 100.0),
                      child: Text(
                        "Aún no has guardado favoritos.\n¡Pulsa el ❤️ en un servicio!",
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 18, color: Colors.grey[600]),
                      ),
                    ),
                  )
                : GridView.builder(
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 16.0,
                      mainAxisSpacing: 24.0,
                      childAspectRatio: 0.75,
                    ),
                    itemCount: _favoriteServices.length,
                    itemBuilder: (context, index) {
                      final service = _favoriteServices[index];
                      return InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  ServiceDetailPage(service: service),
                            ),
                          );
                        },
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Card(
                              elevation: 4.0,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0)),
                              clipBehavior: Clip.antiAlias,
                              child: Image.network(
                                service.imagePath,
                                height: 160,
                                width: double.infinity,
                                fit: BoxFit.cover,
                              ),
                            ),
                            SizedBox(height: 8.0),
                            Text(
                              service.title,
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.bold),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ],
        ),
      ),
    );
  }
}
