import 'package:flutter/material.dart';
import 'login_screen.dart';
import 'service_detail_page.dart';
import '../models/user_manager.dart';

class ServiceItem {
  final String title;
  final String imagePath;
  final double price;
  final String category;

  int likeCount;

  ServiceItem({
    required this.title,
    required this.imagePath,
    required this.price,
    required this.category,
    this.likeCount = 0,
  });
}

final List<ServiceItem> allServices = [
  ServiceItem(
      title: "Corte de pelo corto",
      imagePath: "https://i.imgur.com/L4yT2xR.jpeg",
      price: 15.00,
      category: "Populares",
      likeCount: 5),
  ServiceItem(
      title: "Arreglo de barba",
      imagePath: "https://i.imgur.com/JbW0m9T.jpeg",
      price: 10.00,
      category: "Populares",
      likeCount: 12),
  ServiceItem(
      title: "Tinte y mechas",
      imagePath: "https://i.imgur.com/tY8K4qC.jpeg",
      price: 45.00,
      category: "Mujeres",
      likeCount: 8),
  ServiceItem(
      title: "Corte básico (Hombre)",
      imagePath: "https://i.imgur.com/L4yT2xR.jpeg",
      price: 12.00,
      category: "Baratos"),
  ServiceItem(
      title: "Corte básico (Mujer)",
      imagePath: "https://i.imgur.com/tY8K4qC.jpeg",
      price: 18.00,
      category: "Mujeres"),
  ServiceItem(
      title: "Corte y peinado",
      imagePath: "https://i.imgur.com/JbW0m9T.jpeg",
      price: 20.00,
      category: "Hombres",
      likeCount: 3),
];

enum SortOption { none, priceAsc, priceDesc, likesDesc }

class HomeTabPage extends StatefulWidget {
  final String userName;

  HomeTabPage({Key? key, required this.userName}) : super(key: key);

  @override
  _HomeTabPageState createState() => _HomeTabPageState();
}

class _HomeTabPageState extends State<HomeTabPage> {
  String _selectedFilter = "Todos";
  List<ServiceItem> _filteredServices = [];
  final _searchController = TextEditingController();
  String _searchQuery = "";
  SortOption _sortOption = SortOption.none;

  User? currentUser;

  @override
  void initState() {
    super.initState();
    currentUser = UserManager.getUserByName(widget.userName);
    _filterServices();
  }

  void _filterServices() {
    setState(() {
      List<ServiceItem> tempServices = [];

      if (_selectedFilter == "Todos") {
        tempServices = List.from(allServices);
      } else {
        tempServices = allServices
            .where((service) => service.category == _selectedFilter)
            .toList();
      }

      if (_searchQuery.isNotEmpty) {
        tempServices = tempServices
            .where((service) => service.title
                .toLowerCase()
                .contains(_searchQuery.toLowerCase()))
            .toList();
      }

      _filteredServices = tempServices;

      switch (_sortOption) {
        case SortOption.priceAsc:
          _filteredServices.sort((a, b) => a.price.compareTo(b.price));
          break;
        case SortOption.priceDesc:
          _filteredServices.sort((a, b) => b.price.compareTo(a.price));
          break;
        case SortOption.likesDesc:
          _filteredServices.sort((a, b) => b.likeCount.compareTo(a.likeCount));
          break;
        case SortOption.none:
          break;
      }
    });
  }

  void _showProfileDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
          ),
          contentPadding: EdgeInsets.all(20),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircleAvatar(
                radius: 30,
                backgroundImage: NetworkImage(currentUser?.photoPath ??
                    "https://i.imgur.com/lB5bLMY.jpg"),
              ),
              SizedBox(height: 15),
              Text(
                "¡Hola, ${widget.userName}!",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 20),
              Divider(),
              ListTile(
                leading: Icon(Icons.logout),
                title: Text("Cerrar sesión"),
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (context) => LoginScreen()),
                    (Route<dynamic> route) => false,
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void _showFilterDialog() {
    SortOption tempSortOption = _sortOption;

    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      isScrollControlled: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setDialogState) {
            return SingleChildScrollView(
              child: Container(
                padding: EdgeInsets.fromLTRB(20, 20, 20, 55),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Ordenar por",
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 10),
                    RadioListTile<SortOption>(
                      title: Text("Relevancia (defecto)"),
                      value: SortOption.none,
                      groupValue: tempSortOption,
                      onChanged: (value) {
                        setDialogState(() {
                          tempSortOption = value!;
                        });
                      },
                    ),
                    RadioListTile<SortOption>(
                      title: Text("Precio: más barato"),
                      value: SortOption.priceAsc,
                      groupValue: tempSortOption,
                      onChanged: (value) {
                        setDialogState(() {
                          tempSortOption = value!;
                        });
                      },
                    ),
                    RadioListTile<SortOption>(
                      title: Text("Precio: más caro"),
                      value: SortOption.priceDesc,
                      groupValue: tempSortOption,
                      onChanged: (value) {
                        setDialogState(() {
                          tempSortOption = value!;
                        });
                      },
                    ),
                    RadioListTile<SortOption>(
                      title: Text("Más populares (Likes)"),
                      value: SortOption.likesDesc,
                      groupValue: tempSortOption,
                      onChanged: (value) {
                        setDialogState(() {
                          tempSortOption = value!;
                        });
                      },
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange.shade700,
                        foregroundColor: Colors.white,
                        minimumSize: const Size(double.infinity, 50),
                      ),
                      child: Text("Aplicar Filtros"),
                      onPressed: () {
                        setState(() {
                          _sortOption = tempSortOption;
                        });
                        Navigator.pop(context);
                        _filterServices();
                      },
                    )
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(20.0),
          children: [
            _buildHeader(),
            SizedBox(height: 20),
            _buildSearchBar(),
            SizedBox(height: 20),
            _buildSectionHeader(),
            SizedBox(height: 10),
            _buildFilterChips(),
            SizedBox(height: 20),
            _buildServiceList(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          "Hola, ${widget.userName} 👋",
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
          ),
        ),
        InkWell(
          onTap: () => _showProfileDialog(context),
          borderRadius: BorderRadius.circular(25),
          child: CircleAvatar(
            radius: 25,
            backgroundImage: NetworkImage(
                currentUser?.photoPath ?? "https://i.imgur.com/lB5bLMY.jpg"),
          ),
        ),
      ],
    );
  }

  Widget _buildSearchBar() {
    return TextField(
      controller: _searchController,
      onChanged: (query) {
        setState(() {
          _searchQuery = query;
          _filterServices();
        });
      },
      decoration: InputDecoration(
        hintText: "Buscar servicio",
        prefixIcon: Icon(Icons.search),
        suffixIcon: IconButton(
          icon: Icon(Icons.tune),
          onPressed: _showFilterDialog,
        ),
        filled: true,
        fillColor: Colors.grey[200],
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30.0),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Widget _buildSectionHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Text(
          "Servicios",
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildFilterChips() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          _buildChip("Todos"),
          SizedBox(width: 10),
          _buildChip("Populares"),
          SizedBox(width: 10),
          _buildChip("Baratos"),
          SizedBox(width: 10),
          _buildChip("Mujeres"),
          SizedBox(width: 10),
          _buildChip("Hombres"),
        ],
      ),
    );
  }

  Widget _buildChip(String label) {
    bool isSelected = _selectedFilter == label;
    return ChoiceChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (selected) {
        if (selected) {
          setState(() {
            _selectedFilter = label;
            _filterServices();
          });
        }
      },
      selectedColor: Colors.orange.shade700,
      labelStyle: TextStyle(
        color: isSelected ? Colors.white : Colors.black,
      ),
      backgroundColor: Colors.grey[200],
      shape: StadiumBorder(side: BorderSide(color: Colors.transparent)),
    );
  }

  Widget _buildServiceList() {
    if (_filteredServices.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Text(
            "No se encontraron servicios que coincidan.",
            style: TextStyle(fontSize: 16, color: Colors.grey[600]),
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    return ListView.builder(
      itemCount: _filteredServices.length,
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemBuilder: (context, index) {
        final service = _filteredServices[index];

        return ServiceCard(
            service: service, showLikes: true, userName: widget.userName);
      },
    );
  }
}

class ServiceCard extends StatefulWidget {
  final ServiceItem service;
  final bool showLikes;
  final String? userName;

  const ServiceCard(
      {Key? key, required this.service, this.showLikes = true, this.userName})
      : super(key: key);

  @override
  _ServiceCardState createState() => _ServiceCardState();
}

class _ServiceCardState extends State<ServiceCard> {
  bool _isLiked = false;
  late int _likeCount;

  @override
  void initState() {
    super.initState();
    _likeCount = widget.service.likeCount;

    if (widget.userName != null) {
      _isLiked =
          UserManager.isServiceLiked(widget.userName!, widget.service.title);
    }
  }

  void _navigateToDetail() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ServiceDetailPage(service: widget.service),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4.0,
      margin: EdgeInsets.only(bottom: 15.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: _navigateToDetail,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.vertical(top: Radius.circular(15.0)),
              child: Image.network(widget.service.imagePath,
                  height: 180, width: double.infinity, fit: BoxFit.cover),
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Flexible(
                    child: Text(
                      widget.service.title,
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (widget.showLikes)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(width: 8),
                        IconButton(
                          padding: EdgeInsets.zero,
                          constraints: BoxConstraints(),
                          icon: Icon(
                            _isLiked ? Icons.favorite : Icons.favorite_border,
                            color: _isLiked ? Colors.red : Colors.grey[600],
                            size: 24,
                          ),
                          onPressed: () {
                            if (widget.userName == null) return;

                            setState(() {
                              _isLiked = !_isLiked;
                              if (_isLiked) {
                                _likeCount++;
                              } else {
                                _likeCount--;
                              }

                              UserManager.toggleLike(
                                  widget.userName!, widget.service.title);

                              widget.service.likeCount = _likeCount;
                            });
                          },
                        ),
                        SizedBox(width: 4),
                        Text(
                          _likeCount.toString(),
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[800],
                          ),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
