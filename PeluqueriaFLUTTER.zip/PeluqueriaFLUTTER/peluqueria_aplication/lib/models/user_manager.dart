class User {
  String name;
  final String email;
  final String password;

  String phone;
  String allergens;
  String conditions;

  String photoPath;

  List<String> favoriteServices;

  User({
    required this.name,
    required this.email,
    required this.password,
    this.phone = "",
    this.allergens = "",
    this.conditions = "",
    this.photoPath = "https://i.imgur.com/lB5bLMY.jpg",
    List<String>? favoriteServices,
  }) : this.favoriteServices = favoriteServices ?? [];
}

class UserManager {
  static final List<User> _users = [];

  static void registerUser(String name, String email, String password) {
    _users.add(User(name: name, email: email, password: password));
    print("Usuario registrado: $email");
  }

  static User? loginUser(String email, String password) {
    try {
      return _users.firstWhere(
        (user) => user.email == email && user.password == password,
      );
    } catch (e) {
      return null;
    }
  }

  static bool emailExists(String email) {
    return _users.any((user) => user.email == email);
  }

  static User? getUserByName(String name) {
    try {
      return _users.firstWhere((user) => user.name == name);
    } catch (e) {
      return null;
    }
  }

  static bool isServiceLiked(String userName, String serviceTitle) {
    User? user = getUserByName(userName);
    if (user != null) {
      return user.favoriteServices.contains(serviceTitle);
    }
    return false;
  }

  static void toggleLike(String userName, String serviceTitle) {
    User? user = getUserByName(userName);
    if (user != null) {
      if (user.favoriteServices.contains(serviceTitle)) {
        user.favoriteServices.remove(serviceTitle);
      } else {
        user.favoriteServices.add(serviceTitle);
      }
    }
  }
}
