package com.example.peluqueria_aplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
